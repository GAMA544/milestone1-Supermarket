// Main function to render products added to the shopping cart
function renderizarCarrinho() {
  const listaCarro = document.getElementById("lista-carro");
  const listaResumo = document.getElementById("lista-resumo");
  const totalCompra = document.getElementById("total-compra");

  // Load cart data from sessionStorage
  let carrinho = JSON.parse(sessionStorage.getItem("carrinho")) || [];

  listaCarro.innerHTML = "";  // Clear current cart view
  listaResumo.innerHTML = ""; // Clear summary section

  let total = 0;

  // Iterate over cart items and render each
  carrinho.forEach(item => {
    const subtotal = item.quantidade * item.preco;
    total += subtotal;

    const divProduto = document.createElement("div");
    divProduto.classList.add("item-carrinho");

    // HTML structure for each product in the cart
    divProduto.innerHTML = `
      <img src="${item.imagem}" alt="${item.nome}">
      <div>
        <h3>${item.nome}</h3>
        <p class="marca">${item.marca || ""}</p>
        <div class="quantidade-controle">
          <button onclick="alterarQtd('${item._id}', -1)">−</button>
          <input type="number" id="qtd-${item._id}" value="${item.quantidade}" min="1" readonly>
          <button onclick="alterarQtd('${item._id}', 1)">+</button>
          <button onclick="removerProduto('${item._id}')" title="Remover produto" style="margin-left: 10px; background-color: red;">
            🗑️
          </button>
        </div>
        <p><strong>R$ ${(item.preco).toFixed(2)}</strong></p>
      </div>
    `;

    listaCarro.appendChild(divProduto);

    // Add product to the summary section
    const liResumo = document.createElement("li");
    liResumo.innerHTML = `<span>– ${item.nome}</span><span>R$ ${subtotal.toFixed(2)}</span>`;
    listaResumo.appendChild(liResumo);
  });

  // Display total amount
  totalCompra.textContent = `R$ ${total.toFixed(2)}`;
}
// Function to change the quantity of a cart item (+1 or -1)
async function alterarQtd(id, delta) {
  let carrinho = JSON.parse(sessionStorage.getItem("carrinho")) || [];
  const item = carrinho.find(p => p._id === id);
  if (!item) return;

  try {
    // Check real-time stock from backend
    const res = await fetch(`http://localhost:3000/api/produtos/${id}`);
    if (!res.ok) throw new Error("Erro ao buscar produto");
    const produto = await res.json();

    const estoque = produto.estoque;

    // Prevent exceeding available stock
    if (delta > 0 && item.quantidade >= estoque) {
      alert(`Estoque insuficiente. Máximo disponível: ${estoque}`);
      return;
    }

    item.quantidade += delta;
    if (item.quantidade < 1) item.quantidade = 1;

    sessionStorage.setItem("carrinho", JSON.stringify(carrinho));
    renderizarCarrinho(); // Re-render the updated cart
  } catch (error) {
    console.error("Erro ao verificar estoque:", error);
    alert("Erro ao atualizar quantidade. Tente novamente.");
  }
}
// Function to completely remove an item from the cart
function removerProduto(id) {
  let carrinho = JSON.parse(sessionStorage.getItem("carrinho")) || [];
  carrinho = carrinho.filter(p => p._id !== id); // Remove item by ID
  sessionStorage.setItem("carrinho", JSON.stringify(carrinho));
  renderizarCarrinho(); // Refresh cart display
}
// Function to validate cart and proceed to payment page
async function avanzarCompra() {
  const usuario = JSON.parse(sessionStorage.getItem("loggedUser"));
  const carrinho = JSON.parse(sessionStorage.getItem("carrinho")) || [];

  // Redirect if not logged in
  if (!usuario || !usuario.name) {
    alert("Você precisa estar logado para enviar uma mensagem.");
    window.location.href = "loginpage.html";
    return;
  }

  // Check stock for each product before proceeding
  for (const item of carrinho) {
    try {
      const res = await fetch(`http://localhost:3000/api/produtos/${item._id}`);
      if (!res.ok) throw new Error();
      const produto = await res.json();

      if (item.quantidade > produto.estoque) {
        alert(`A quantidade do produto "${item.nome}" excede o estoque disponível (${produto.estoque}).`);
        return;
      }
    } catch (err) {
      alert("Erro ao verificar o estoque. Tente novamente.");
      return;
    }
  }

  // Redirect to payment page if all validations pass
  window.location.href = "pagamento.html";
}
// Ensure the cart is rendered as soon as the page loads
document.addEventListener("DOMContentLoaded", renderizarCarrinho);
