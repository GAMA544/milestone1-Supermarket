// 🔁 Asynchronous function to dynamically render unique product categories as clickable list items
async function renderizarCategorias(containerId = "lista-categorias") {
  const container = document.getElementById(containerId);
  if (!container) {
    console.warn(`Contêiner "${containerId}" não encontrado no DOM.`); // Warn if the container is missing
    return;
  }

  // 🔄 Fetch products from the backend
  let produtos = [];
  try {
    const res = await fetch("http://localhost:3000/api/produtos");
    produtos = await res.json(); // Parse response as JSON array
  } catch (err) {
    console.error("Erro ao carregar produtos:", err); // Log error if fetch fails
    return;
  }

  // 🚫 Exit if no products were fetched
  if (produtos.length === 0) {
    console.warn("Nenhum produto carregado.");
    return;
  }

  // 🏷️ Extract unique category names using Set
  const categorias = [...new Set(produtos.map(p => p.categoria))];
  container.innerHTML = ""; // Clear any existing content

  // 🧱 Create list item for each category
  categorias.forEach(cat => {
    const item = document.createElement("li");
    item.textContent = cat;               // Display category name
    item.className = "cat-item";          // Apply styling class
    item.dataset.categoria = cat;         // Store category value in data attribute

    // Highlight default category (e.g., "Frutas")
    if (cat === "Frutas") {
      item.classList.add("active");
    }

    // 📌 Handle click: activate and filter category
    item.addEventListener("click", () => {
      if (item.classList.contains("active")) return; // Skip if already active

      document.querySelectorAll(".cat-item").forEach(li => li.classList.remove("active")); // Remove active state
      item.classList.add("active"); // Activate clicked item

      filtrarPorCategoria(cat); // 🧠 Call existing function to filter by category
    });

    container.appendChild(item); // Add item to container
  });

  // 🟢 Automatically filter by default or first category
  if (categorias.includes("Frutas")) {
    filtrarPorCategoria("Frutas");
  } else {
    filtrarPorCategoria(categorias[0]);
  }
}
