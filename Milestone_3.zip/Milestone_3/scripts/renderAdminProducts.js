// Wait for the full DOM to be loaded
document.addEventListener("DOMContentLoaded", async () => {
  const tbody = document.querySelector(".scrollable-tbody tbody");
  if (!tbody) return; // Exit if table body is not present

  // 🔄 Load products from the backend API
  let produtos = [];
  try {
    const res = await fetch("http://localhost:3000/api/produtos");
    if (!res.ok) throw new Error("Erro de resposta do servidor"); // Handle non-200 responses
    produtos = await res.json(); // Parse JSON response
  } catch (err) {
    console.error("Erro ao carregar produtos:", err); // Log fetch error
    tbody.innerHTML = `<tr><td colspan="7">Erro ao carregar produtos.</td></tr>`; // Show error in UI
    return;
  }

  // 🧹 Clear the current table body before rendering new data
  tbody.innerHTML = "";

  // ➕ Render each product as a new row in the table
  produtos.forEach((produto, index) => {
    const tr = document.createElement("tr");

    tr.innerHTML = `
      <td>${index + 1}</td>
      <td class="asset-name">
        <img src="${produto.imagem}" alt="${produto.nome}" class="asset-icon">
        <span>${produto.nome}</span>
      </td>
      <td>${produto.apresentacao || '-'}</td>
      <td>${produto.categoria}</td>
      <td>R$${parseFloat(produto.preco).toFixed(2).replace('.', ',')}</td>
      <td>${produto.estoque}</td>
      <td class="action-buttons">
        <button class="btn-icon edit" data-id="${produto._id}">
          <i class="fas fa-edit"></i>
        </button>
        <button class="btn-icon delete" data-id="${produto._id}">
          <i class="fas fa-trash-alt"></i>
        </button>
      </td>
    `;

    tbody.appendChild(tr); // Add the row to the table
  });

  // ✏️ Handle edit button click: store product ID and redirect to edit page
  document.querySelectorAll(".btn-icon.edit").forEach(btn => {
    btn.addEventListener("click", (e) => {
      const id = e.currentTarget.dataset.id;
      localStorage.setItem("editandoProdutoId", id); // Temporarily store product ID
      window.location.href = "admin-edit-product.html"; // Redirect to edit form
    });
  });

  // 🗑️ Handle delete button click: confirm and delete product from backend
  document.querySelectorAll(".btn-icon.delete").forEach(btn => {
    btn.addEventListener("click", async (e) => {
      const id = e.currentTarget.dataset.id;

      if (confirm("Deseja realmente excluir este produto?")) {
        try {
          const res = await fetch(`http://localhost:3000/api/produtos/${id}`, {
            method: "DELETE",
          });

          if (res.ok) {
            alert("Produto removido com sucesso."); // Notify success
            location.reload(); // Reload page to update table
          } else {
            alert("Erro ao remover produto."); // Handle failure
          }
        } catch (err) {
          console.error("Erro ao excluir produto:", err);
          alert("Erro inesperado ao excluir produto."); // Handle unexpected error
        }
      }
    });
  });
});
