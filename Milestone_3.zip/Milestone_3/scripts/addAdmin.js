// Waits for the full DOM to be loaded before executing the script
document.addEventListener("DOMContentLoaded", () => {
  // Get references to the input fields for CPF, phone number, and name
  const cpfInput = document.getElementById("documento");
  const phoneInput = document.getElementById("telefone");
  const nameInput = document.getElementById("nome");

  // CPF input mask: formats the input as XXX.XXX.XXX-XX
  cpfInput.addEventListener("input", () => {
    let value = cpfInput.value.replace(/\D/g, ""); // Remove all non-digit characters
    if (value.length > 11) value = value.slice(0, 11); // Limit to 11 digits
    value = value.replace(/(\d{3})(\d)/, "$1.$2")      // Insert first dot
                 .replace(/(\d{3})(\d)/, "$1.$2")      // Insert second dot
                 .replace(/(\d{3})(\d{1,2})$/, "$1-$2"); // Insert hyphen before the last two digits
    cpfInput.value = value; // Update the input field with the formatted value
  });

  // Phone number input mask: formats as (XX) XXXXX-XXXX
  phoneInput.addEventListener("input", () => {
    let value = phoneInput.value.replace(/\D/g, ""); // Remove non-digit characters
    if (value.length > 11) value = value.slice(0, 11); // Limit to 11 digits
    value = value.replace(/^(\d{2})(\d)/, "($1) $2")   // Add area code in parentheses
                 .replace(/(\d{5})(\d)/, "$1-$2");     // Add hyphen after five digits
    phoneInput.value = value; // Update input field with formatted value
  });

  // Restrict name input to only letters (including accents) and spaces
  nameInput.addEventListener("input", () => {
    nameInput.value = nameInput.value.replace(/[^A-Za-zÀ-ÿ\s]/g, ""); // Remove any invalid characters
  });

  // Select the registration form
  const form = document.querySelector(".formulario-registro");

  // Attach a submit event listener to the form
  form.addEventListener("submit", async function (event) {
    event.preventDefault(); // Prevent default form submission behavior (page reload)

    // Create a new user object from form values
    const novoUsuario = {
      CPF: cpfInput.value.trim(),
      name: nameInput.value.trim(),
      address: document.getElementById("endereco").value.trim(),
      phone: phoneInput.value.trim(),
      email: document.getElementById("email").value.trim(),
      password: document.getElementById("senha").value,
      role: "admin" // The default role is "admin" for this form
    };

    try {
      // Send a POST request to the backend API to register the new user
      const res = await fetch("http://localhost:3000/api/usuarios", {
        method: "POST",
        headers: { "Content-Type": "application/json" }, // Set JSON header
        body: JSON.stringify(novoUsuario) // Convert the user object to JSON string
      });

      // If registration fails, display the error message
      if (!res.ok) {
        const erro = await res.json();
        alert(erro.message || "Erro ao registrar usuário.");
        return;
      }

      // If successful, get the created user from the response
      const userCriado = await res.json();

      // Store the logged user in sessionStorage (temporary session storage)
      sessionStorage.setItem("loggedUser", JSON.stringify(userCriado));

      // Show success message and redirect to the main products page
      alert("Usuário registrado com sucesso!");
      window.location.href = "Produtos_Page.html";
    } catch (error) {
      // Handle any network or unexpected errors
      console.error("Erro de rede:", error);
      alert("Erro ao conectar com o servidor.");
    }
  });
});
