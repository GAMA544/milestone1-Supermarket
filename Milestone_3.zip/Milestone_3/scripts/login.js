document.addEventListener("DOMContentLoaded", () => {

  // 🔒 If a session is already active, redirect the user
  const usuarioLogado = sessionStorage.getItem("loggedUser");
  if (usuarioLogado) {
    const user = JSON.parse(usuarioLogado); // Parse session data
    alert("Já existe uma sessão ativa."); // Alert user of active session
    window.location.href = user.role === "admin" ? "admin-productos.html" : "Produtos_Page.html"; // Redirect based on role
    return; // Prevent further script execution
  }

  // Select the login form element
  const form = document.querySelector("form");

  // 🔐 Attach an event listener to handle login form submission
  form.addEventListener("submit", async (event) => {
    event.preventDefault(); // Prevent default form behavior (page reload)

    // Capture user input (email or CPF, and password)
    const inputEmail = document.getElementById("email").value.trim();
    const inputSenha = document.getElementById("password").value;

    try {
      // Send a POST request to the login endpoint of the backend API
      const res = await fetch("http://localhost:3000/api/usuarios/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" }, // Set request content type
        body: JSON.stringify({ emailOuCPF: inputEmail, senha: inputSenha }) // Send login data as JSON
      });

      // Handle error response from server
      if (!res.ok) {
        const erro = await res.json();
        throw new Error(erro.erro || "Usuário ou senha inválidos."); // Raise user-friendly error
      }

      // If login successful, store user session data
      const user = await res.json();
      sessionStorage.setItem("loggedUser", JSON.stringify(user));

      alert("Login realizado com sucesso!"); // Notify user
      window.location.href = user.role === "admin" ? "admin-productos.html" : "Produtos_Page.html"; // Redirect based on role

    } catch (err) {
      // Handle network or server-side errors
      console.error("Erro ao fazer login:", err);
      alert("Erro ao fazer login: " + err.message);
    }
  });

});
