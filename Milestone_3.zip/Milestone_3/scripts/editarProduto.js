document.addEventListener("DOMContentLoaded", async () => {
  // 🔎 Retrieve the product ID saved earlier in localStorage
  const idProduto = localStorage.getItem("editandoProdutoId");

  // If no ID was found, alert the user and stop the script
  if (!idProduto) {
    alert("ID do produto não fornecido."); // Product ID not provided
    return;
  }

  let produto;

  try {
    // Fetch product data from backend API using the stored ID
    const res = await fetch(`http://localhost:3000/api/produtos/${idProduto}`);
    if (!res.ok) throw new Error("Produto não encontrado."); // Product not found
    produto = await res.json(); // Parse response as JSON
  } catch (err) {
    console.error("Erro ao buscar produto:", err); // Log the error
    alert("Erro ao carregar dados do produto."); // Notify user
    return;
  }

  // 📝 Fill the form fields with the product data retrieved from MongoDB
  document.getElementById("id").value = produto._id;
  document.getElementById("nome").value = produto.nome;
  document.getElementById("preco").value = produto.preco;
  document.getElementById("descricao").value = produto.descricao;
  document.getElementById("imagem").value = produto.imagem;
  document.getElementById("estoque").value = produto.estoque;
  document.getElementById("vendidos").value = produto.vendidos;
  document.getElementById("categoria").value = produto.categoria;
  document.getElementById("marca").value = produto.marca;
  document.getElementById("unidade").value = produto.apresentacao;

  // 💾 On form submission, send an update request to the backend
  document.getElementById("form-produto").addEventListener("submit", async (e) => {
    e.preventDefault(); // Prevent default form behavior

    // Build the updated product object from current form values
    const produtoAtualizado = {
      nome: document.getElementById("nome").value.trim(),
      preco: parseFloat(document.getElementById("preco").value),
      descricao: document.getElementById("descricao").value.trim(),
      imagem: document.getElementById("imagem").value.trim(),
      estoque: parseInt(document.getElementById("estoque").value),
      vendidos: parseInt(document.getElementById("vendidos").value),
      categoria: document.getElementById("categoria").value.trim(),
      marca: document.getElementById("marca").value.trim(),
      apresentacao: document.getElementById("unidade").value.trim()
    };

    // Simple numeric validation
    if (
      isNaN(produtoAtualizado.preco) ||
      isNaN(produtoAtualizado.estoque) ||
      isNaN(produtoAtualizado.vendidos)
    ) {
      alert("Preencha corretamente os campos numéricos."); // Warn if numeric fields are invalid
      return;
    }

    try {
      // Send PUT request to update the product in the backend database (MongoDB Atlas)
      const response = await fetch(`http://localhost:3000/api/produtos/${idProduto}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(produtoAtualizado)
      });

      if (!response.ok) throw new Error("Erro ao atualizar produto");

      alert("Produto atualizado com sucesso!"); // Notify success
      localStorage.removeItem("editandoProdutoId"); // Clean up temporary ID
      window.location.href = "admin-productos.html"; // Redirect to product list
    } catch (error) {
      console.error("Erro ao atualizar:", error); // Log the error
      alert("Erro ao atualizar produto."); // Notify failure
    }
  });
});
