// Wait until the DOM is fully loaded before executing
document.addEventListener("DOMContentLoaded", async () => {
  const tbody = document.querySelector(".scrollable-tbody tbody");
  if (!tbody) return; // Exit if table structure is missing

  try {
    // 🔄 Fetch all users from backend API
    const res = await fetch("http://localhost:3000/api/usuarios");
    if (!res.ok) throw new Error("Erro ao buscar usuários"); // Handle request failure
    const users = await res.json(); // Parse JSON response

    // 🧹 Clear the table body before rendering
    tbody.innerHTML = "";

    // ➕ Render each user as a table row
    users.forEach((user) => {
      const tr = document.createElement("tr");

      tr.innerHTML = `
        <td>${user._id}</td>
        <td>${user.name}</td>
        <td>${user.email}</td>
        <td>${user.role}</td>
        <td>${user.ativo === false ? "Inativo" : "Ativo"}</td>
        <td class="action-buttons">
          <button class="btn-icon edit" data-id="${user._id}">
            <i class="fas fa-edit"></i>
          </button>
          <button class="btn-icon delete" data-id="${user._id}">
            <i class="fas fa-trash-alt"></i>
          </button>
        </td>
      `;

      tbody.appendChild(tr); // Append the row to the table
    });

    // 🗑️ Handle user deletion logic
    document.querySelectorAll(".btn-icon.delete").forEach(btn => {
      btn.addEventListener("click", async (e) => {
        const id = e.currentTarget.dataset.id;
        const user = users.find(u => u._id === id);

        // Prevent deletion of primary admin
        if (user && user.name === "Nest") {
          alert("Não é possível excluir o administrador principal.");
          return;
        }

        if (confirm("Deseja realmente excluir este usuário?")) {
          try {
            const loggedUser = JSON.parse(sessionStorage.getItem("loggedUser"));

            // Send DELETE request to backend
            const resDel = await fetch(`http://localhost:3000/api/usuarios/${id}`, {
              method: "DELETE"
            });

            if (!resDel.ok) throw new Error("Erro ao excluir usuário");

            // If logged-in user deleted themselves
            if (loggedUser && loggedUser._id === id) {
              sessionStorage.removeItem("loggedUser");
              alert("Sua conta foi excluída. Você será redirecionado para a página inicial.");
              setTimeout(() => {
                window.location.href = "homepage.html";
              }, 300);
            } else {
              alert("Usuário excluído com sucesso!");
              location.reload(); // Refresh to update the list
            }

          } catch (err) {
            console.error(err);
            alert("Erro ao excluir usuário.");
          }
        }
      });
    });

    // ✏️ Handle edit button: store user ID and redirect
    document.querySelectorAll(".btn-icon.edit").forEach(btn => {
      btn.addEventListener("click", (e) => {
        const id = e.currentTarget.dataset.id;
        localStorage.setItem("editandoUsuarioId", id); // Temporarily store ID
        window.location.href = "admin-edit-user.html"; // Redirect to edit page
      });
    });

  } catch (err) {
    console.error("Erro ao carregar usuários:", err); // Log global fetch error
    alert("Erro ao carregar lista de usuários."); // Notify user
  }
});
