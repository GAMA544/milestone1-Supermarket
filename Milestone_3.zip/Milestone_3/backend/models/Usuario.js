const mongoose = require("mongoose");

const usuarioSchema = new mongoose.Schema({
  CPF: { type: String, required: true },
  name: { type: String, required: true },
  address: String,
  phone: String,
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  role: { type: String, enum: ["admin", "client"], default: "client" },
  ativo: { type: Boolean, default: true }
});

module.exports = mongoose.model("Usuario", usuarioSchema);
