const mongoose = require('mongoose');

const ProdutoSchema = new mongoose.Schema({
  nome: String,
  preco: Number,
  descricao: String,
  imagem: String,
  estoque: Number,
  vendidos: Number,
  categoria: String,
  marca: String,
  apresentacao: String
});

module.exports = mongoose.model('Produto', ProdutoSchema);
