// routes/usuarios.js
const express = require('express');
const router = express.Router();
const User = require('../models/Usuario');

router.get('/admin', async (req, res) => {
  try {
    const existe = await User.findOne({ email: "nest@empresa.com" });
    if (existe) {
      return res.status(200).json({ message: "Admin já existe." });
    }

    const novoAdmin = new User({
      CPF: "000.000.000-00",
      name: "Nest",
      address: "Av. Central, 123 - São Paulo",
      phone: "(11) 99999-9999",
      email: "nest@empresa.com",
      password: "admin123",
      role: "admin"
    });

    await novoAdmin.save();
    res.status(201).json({ message: "Admin criado com sucesso." });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Erro ao criar admin." });
  }
});

// routes/usuarios.js
router.post('/login', async (req, res) => {
  const { emailOuCPF, senha } = req.body;

  try {
    const usuario = await Usuario.findOne({
      $or: [{ email: emailOuCPF }, { CPF: emailOuCPF }]
    });

    if (!usuario || usuario.password !== senha) {
      return res.status(401).json({ erro: "Credenciais inválidas" });
    }

    res.json(usuario);
  } catch (err) {
    res.status(500).json({ erro: "Erro no login" });
  }
});

router.post("/", async (req, res) => {
  const { CPF, name, address, phone, email, password, role } = req.body;

  try {
    const jaExiste = await Usuario.findOne({ email });
    if (jaExiste) return res.status(400).json({ erro: "E-mail já cadastrado." });

    const novo = new Usuario({ CPF, name, address, phone, email, password, role });
    await novo.save();
    res.status(201).json(novo);

  } catch (err) {
    res.status(500).json({ erro: "Erro ao criar usuário." });
  }
});

module.exports = router;
