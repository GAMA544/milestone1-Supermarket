const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
require('dotenv').config();

const produtosRoutes = require('./routes/produtos');
const initUserRouter = require('./routes/initUser');
const usuariosRouter = require('./routes/usuarios');

const app = express();

// 🔒 Middleware de segurança e JSON
app.use(cors());
app.use(express.json());

// 🌐 Conexão com o MongoDB Atlas
mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log('✅ Conectado a MongoDB Atlas'))
  .catch(err => console.error('❌ Erro ao conectar ao MongoDB:', err));

// 📦 Rotas da API
app.use('/api/produtos', produtosRoutes); // produtos
app.use('/api/init', initUserRouter);     // inicialização de admin
app.use('/api/usuarios', usuariosRouter);


// 🚀 Inicialização do servidor
app.listen(3000, () => {
  console.log('🚀 Servidor rodando na porta 3000: http://localhost:3000');
});
